import { Component, OnInit, Input } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';


export interface Dashboard {
  name : string;
  tiles : Tile[][];
}

export interface Tile {
  name : string;
  img : string;
  time_range : '24hours' | 'week' | 'month';
  type : 'line chart' | 'bar chart' | 'pie chart';
}


@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  closeResult: string;

  constructor(private modalService: NgbModal) {}

  currentTile : any;

  open(content: any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  @Input() name: string;

  dashboard : Dashboard = {
    name : 'Test',
    tiles : [
      [
        {
          name : 'Test-1',
          type : 'line chart',
          time_range : '24hours',
          img : 'https://via.placeholder.com/200x100'
        }
      ],
      [
        {
          name : 'Test-2',
          type : 'bar chart',
          time_range : 'week',
          img : 'https://via.placeholder.com/200x100'
        },
        {
          name : 'Test-3',
          type : 'bar chart',
          time_range : 'week',
          img : 'https://via.placeholder.com/200x100'
        }
      ],
      [
        {
          name : 'Test-4',
          type : 'pie chart',
          time_range : 'month',
          img : 'https://via.placeholder.com/200x100'
        },
        {
          name : 'Test-5',
          type : 'bar chart',
          time_range : 'month',
          img : 'https://via.placeholder.com/200x100'
        },
        {
          name : 'Test-6',
          type : 'bar chart',
          time_range : 'month',
          img : 'https://via.placeholder.com/200x100'
        }
      ]
    ]
  };

 onCheck(_checkedval: string)
 {
   // debugger;
   let element = <HTMLInputElement> document.getElementById("customRadio1");
   // let element_time_range = <HTMLInputElement> document.getElementById("options");
   element.checked = true;
   // element_time_range.checked = true;
 }


  getData(){
    console.log(this.dashboard);
  }
  show(dashboard : Dashboard ) {
      this.dashboard = dashboard;
    }

  ngOnInit() {
    console.log(this.dashboard.tiles);
    this.getData();
  }

}
